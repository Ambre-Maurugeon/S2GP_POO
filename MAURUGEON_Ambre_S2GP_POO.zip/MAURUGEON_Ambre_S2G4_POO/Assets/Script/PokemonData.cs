using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PokemonData 
{
    [Serializable]
    public struct Stats{ //encapsuler données ds struct
        public int pv;
        public int atk;
        public int def;
        public int atkSpe;
        public int defSpe;
        public int speed;

        public Stats(int pv, int atk, int def, int atkSpe, int defSpe, int speed)
        {
            this.pv=pv;
            this.atk=atk;
            this.def=def;
            this.atkSpe=atkSpe;
            this.defSpe=defSpe;
            this.speed=speed;
        }

        public Stats(Stats statsBase, int coeff){

            pv = statsBase.pv *coeff;
            atk = statsBase.atk*coeff;
            def = statsBase.def*coeff;
            atkSpe = statsBase.atkSpe*coeff;
            defSpe = statsBase.defSpe*coeff;
            speed = statsBase.speed*coeff;
        }
    }
    public enum Type{
            Acier,
            Combat,
            Dragon,
            Eau,
            Electrique,
            Fée,
            Feu,
            Glace,
            Insecte,
            Normal,
            Plante,
            Poison,
            Psy,
            Roche,
            Sol,
            Spectre,
            Ténèbres,
            Vol
        } ;


    [Serializable]
    public struct Infos{
        
        public int idNumber;

        public string category;

        public float size;
        public float weight;

        public string caption;
        
        public Type[] strengths;
        public Type[] weaknesses;
        public int idPokeBase;

        public Infos(int idNumber, float size, float weight, string category, string caption, Type[] strengths, Type[] weaknesses, int idPokeBase)
        {
        this.idNumber=idNumber;
        this.size=size;
        this.weight=weight;
        this.category=category;
        this.caption=caption;
        this.strengths=strengths;
        this.weaknesses=weaknesses;
        this.idPokeBase=idPokeBase;
        }
    }
    
    
    public string name;
    public Sprite icon;

    public Infos info;
    public Stats statsBase;

    public PokemonData(string name, Sprite icon, Infos info, Stats stats){
        this.name=name;
        this.info=info;
        this.icon=icon;

        statsBase = stats;
    }

    
    public Stats GetStatsByLvl(int lvl, int evolutionStep)=>new(statsBase, (lvl * evolutionStep)/10);
}
