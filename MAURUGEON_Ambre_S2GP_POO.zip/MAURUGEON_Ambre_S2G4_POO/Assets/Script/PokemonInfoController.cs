using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PokemonInfoController : MonoBehaviour
{
    [SerializeField] private Image _imgIcon;
    [SerializeField] private Text _txtName;
    [SerializeField] private Text _txtSize;
    [SerializeField] private Text _txtWeight;
    [SerializeField] private Text _txtCaption; // TMP_Text
    [SerializeField] private Text _txtCategory;

    public DatabaseManager _databaseMgr;
    public PokemonDatabase database;

    private int max;
    public int id;
    private List<PokemonData> datas;

    //variables Fight
    private GameObject UIFight;
    

    private void Awake(){
        _databaseMgr= FindObjectOfType<DatabaseManager>();
        datas = database.datas;
        
        UIFight = GameObject.FindGameObjectWithTag("fight");    
        UIFight.SetActive(false);
    }


    void Update(){
        PokemonData data = _databaseMgr.GetData(id);

        _imgIcon.sprite = data.icon;
        _txtName.text = "N°" + data.info.idNumber.ToString("D4") +" | "+ data.name ;
        
        _txtSize.text = $"Taille : " + $"<b>{data.info.size:f1} m</b>";
        _txtWeight.text = $"Poids : " + $"<b>{data.info.weight:f1} kg </b>";
        _txtCaption.text = data.info.caption.ToString();
        _txtCategory.text = "Catégorie : " + data.info.category;
    }

    //Btn
    public void PreviousBtn(){
        if (id <= 0){
            id = datas.Count-1;
        }else{
            id -=1;
        }
    }

    public void NextBtn(){
        if (id != datas.Count-1){
            id +=1;
        }else{
            id=0;
        }
    }

    //Fight
    private PokemonData monPokemon;
    private PokemonData PokemonOpponent;

    public void GoFight(){              //Bouton Combat
        UIFight.SetActive(true);
    }
    
    //Fonctions appelées dans FightPokemon.cs
    public PokemonData GetMyPokemon(){
        monPokemon = datas[id];
        return monPokemon;
    }

    public PokemonData GetOpponent(int index){
        PokemonOpponent = datas[index];
        return PokemonOpponent;
    }

}
