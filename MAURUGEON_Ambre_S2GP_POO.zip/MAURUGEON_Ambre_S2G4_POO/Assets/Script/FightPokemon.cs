using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class FightPokemon : MonoBehaviour
{
    
    [SerializeField] private PokemonDatabase pokemonDatabase;

    [SerializeField] private PokemonData monPokemon;
    private PokemonData copyMonPokemon;
    [SerializeField] private int ActualHealth;
    [SerializeField] private int Stat;
    
    [SerializeField] private PokemonData PokemonOpponent;
    private PokemonData copyPokemonOpponent;


    //private PokemonData Player;
    private PokemonData[] Players;
    private bool CanCheck;

    [SerializeField] private bool MyPokemonIsWeak=false;
    [SerializeField] private bool OpponentIsWeak=false;


    private int index;
    private System.Random rdm = new System.Random();

    //UI
    [SerializeField] private Image Img_monPokemon;
    [SerializeField] private Image Img_Opponent;
    [SerializeField] private Text text;
    
    
    void Awake(){
        index = rdm.Next(0, pokemonDatabase.datas.Count);
        text = text.GetComponent<Text>();
    }

    void Start()
    {
        PokemonInfoController infoController = FindObjectOfType<PokemonInfoController>();
        monPokemon = infoController.GetMyPokemon();
        PokemonOpponent = infoController.GetOpponent(index);

        // Copier les pokemon pr pas toucher à la database
        copyMonPokemon = new PokemonData(monPokemon.name, monPokemon.icon, monPokemon.info, monPokemon.statsBase);
        copyPokemonOpponent = new PokemonData(PokemonOpponent.name, PokemonOpponent.icon, PokemonOpponent.info, PokemonOpponent.statsBase);

        Img_monPokemon.sprite=monPokemon.icon;
        Img_Opponent.sprite=PokemonOpponent.icon;
        
        StartCoroutine(InitCurrentLife());
        StartCoroutine(InitStatsPoints());
        IsMyPokemonWeak();
        
        StartCoroutine(TakeDamage());

    }

    // Update is called once per frame
    void Update()
    {
        isPokemonAlive();
    }

    IEnumerator InitCurrentLife(){
        yield return new WaitForSeconds(0.1f);
        ActualHealth = monPokemon.statsBase.pv;
    }

    IEnumerator InitStatsPoints(){
        yield return new WaitForSeconds(0.1f);
        Stat = ActualHealth + monPokemon.statsBase.atk + monPokemon.statsBase.def;
    }

    void isPokemonAlive(){
        if(copyMonPokemon.statsBase.pv > 0 && copyPokemonOpponent.statsBase.pv > 0 && CanCheck){
            Debug.Log("Le combat continue, les adversaires sont toujours en vie.");
        }  
        CanCheck=false;
    }

    //2 fonctions (TakeDamage() et AttackOpponent()) en une
    IEnumerator TakeDamage(){
    yield return new WaitForSeconds(0.1f);
    Debug.Log(monPokemon.name + ", notre Pokemon, commence avec " + monPokemon.statsBase.pv + " pv. Et l'ennemi débute avec " + PokemonOpponent.statsBase.pv + " pv.");

    PokemonData[] Players = {copyMonPokemon, copyPokemonOpponent};
    
    while (copyMonPokemon.statsBase.pv > 0 && copyPokemonOpponent.statsBase.pv > 0 )
    {
        for (int i=0; i<2;i++){
            if(Players[i].statsBase.pv > 0){
                if (MyPokemonIsWeak)
                {
                    Players[i].statsBase.pv -= Players[Math.Abs(i-1)].statsBase.atk * 2;  
                    Debug.Log(Players[Math.Abs(i-1)].name + " a infligé " + Players[Math.Abs(i-1)].statsBase.atk * 2 + " de dégats à " + Players[i].name);
                    if(Players[i].statsBase.pv<0){
                        Players[i].statsBase.pv=0;
                    }
                }
                else if (OpponentIsWeak)
                {
                    Players[i].statsBase.pv -= Players[Math.Abs(i-1)].statsBase.atk / 2;
                    if(Players[i].statsBase.pv<0){
                        Players[i].statsBase.pv=0;
                    }
                    Debug.Log(Players[i].name + " a seulement subi " + Players[Math.Abs(i-1)].statsBase.atk / 2 + " dégats.");
                }
                else
                {
                    Players[i].statsBase.pv -= Players[Math.Abs(i-1)].statsBase.atk;
                    if(Players[i].statsBase.pv<0){
                        Players[i].statsBase.pv=0;
                    }
                    Debug.Log(Players[Math.Abs(i-1)].name  + " a infligé " + Players[Math.Abs(i-1)].statsBase.atk + " de dégats.");
                }
                CanCheck = true;

                if (Players[i].statsBase.pv <= 0)
                {
                    Debug.Log(Players[i].name + " est décédé.");
                    text.text = Players[i].name + " est décédé.\n<color=green>" + Players[Math.Abs(i-1)].name + " a gagné.</color>";
                    yield break;
                }
                else
                {
                    Debug.Log(Players[i].name + " se retrouve à " + Players[i].statsBase.pv + " hp.");
                    yield return new WaitForSeconds(0.5f);
                }
            }
        }    
    }
}

    //Check if My Pokemon is weak against Opponent
    void IsMyPokemonWeak(){
        for (int j=0; j<PokemonOpponent.info.strengths.Length;j++)
        {
            for (int i=0; i<monPokemon.info.weaknesses.Length; i++)
            {
                if (PokemonOpponent.info.strengths[j] == monPokemon.info.weaknesses[i]){
                    MyPokemonIsWeak=true;          
                    Debug.Log("L'ennemi a un type fort face à notre pokemon.");
                    return;
                }
            }
        }
        //l'ennemi n'a pas l'ascendant 
        for (int j=0; j<monPokemon.info.strengths.Length;j++)
        {
            for (int i=0; i<PokemonOpponent.info.weaknesses.Length; i++)
            {
                if (monPokemon.info.strengths[j] == PokemonOpponent.info.weaknesses[i]){
                    OpponentIsWeak=true;        
                    Debug.Log("Notre Pokemon a un type fort face à l'ennemi.");
                    return;
                }
            }
        }
        Debug.Log("Le combat s'annonce croustillant, aucun pokemon n'a l'ascendant.");
    }
}
